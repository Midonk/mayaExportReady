
import Sanitizer.setup as setup
setup.createShelf()